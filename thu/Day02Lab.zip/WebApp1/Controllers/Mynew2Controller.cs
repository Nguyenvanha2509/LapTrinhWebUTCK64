﻿using Microsoft.AspNetCore.Mvc;

namespace WebApp1.Controllers
{
    public class Mynew2Controller : Controller
    {
        public IActionResult TrangChu()
        {
            return View();
        }
        public IActionResult CaiDat()
        {
            return View();
        }
    }
}
