﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace NguyenVanHa_231230757_de02.Models
{
    [Table("NVhcatalog")]
    public class NVhCatalog
    {
        public int NVhId { get; set; }
        public string NVhCataName { get; set; }
        public decimal NVhCateprice { get; set; }
        public int NVhCateQty { get; set; }
        [Required]
       
        public string NVhCatePrice { get; set; }
    
        public bool NVhCateActive { get; set; }

    }
}
