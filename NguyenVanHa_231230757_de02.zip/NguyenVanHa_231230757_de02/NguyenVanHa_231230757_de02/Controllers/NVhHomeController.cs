using System.Diagnostics;
using Microsoft.AspNetCore.Mvc;
using NguyenVanHa_231230757_de02.Models;

namespace NguyenVanHa_231230757_de02.Controllers
{
    public class NVhHomeController : Controller
    {
        private readonly ILogger<NVhHomeController> _logger;

        public NVhHomeController(ILogger<NVhHomeController> logger)
        {
            _logger = logger;
        }

        public IActionResult NVhIndex()
        {
            return View();
        }
        public IActionResult NVhAbout()
        {
            return View();
        }

        public IActionResult NVhPrivacy()
        {
            return View();
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult NVhError()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}
