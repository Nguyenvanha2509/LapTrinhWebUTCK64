﻿using Microsoft.AspNetCore.Mvc;

namespace NguyenVanHa_231230757_de02.Controllers
{
    public class NVhCatalogController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }
    }
}
