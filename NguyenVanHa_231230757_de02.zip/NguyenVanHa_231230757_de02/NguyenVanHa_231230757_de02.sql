Create database NguyenVanHa_231230757_de02
use NguyenVanHa_231230757_de02
create table NvhCatalog(
	NvhId int primary key,
	NvhCateName nvarchar(50),
	NvhCatePrice decimal(18,2),
	NvhCateQty int,
	NvhPicture ntext,

	NvhCateActive bit not null

);
drop table NvhCatalog
insert into NvhCatalog (NvhId, NvhCateName,NvhCatePrice, NvhCateQty,NvhPicture,NvhCateActive)
values
(001, N'San pham A', 1200, 5, N'a.jpg',1),
(002, N'San pham A', 2500, 10, N'b.jpg',0),
(003, N'Nguyen Van Ha', 1200, 5, N'sinhvien.jpg',1);